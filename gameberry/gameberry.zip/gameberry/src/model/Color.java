package model;

public enum Color {
  Red, Green, Blue, Yellow;
}
