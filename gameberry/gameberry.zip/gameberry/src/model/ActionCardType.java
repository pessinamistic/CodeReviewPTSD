package model;

public enum ActionCardType {
  ONE,1,2,3,4,5,6,7,8, Skip, Reverse, Draw_Two, Wild , Wild_Draw_Four;
}
